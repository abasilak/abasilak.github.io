	struct NodeTypeDataVariable
	{
		uvec4 data;
	};