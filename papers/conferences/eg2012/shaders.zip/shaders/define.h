﻿#version 420 core
#extension GL_NV_gpu_shader5 : enable
#extension GL_NV_shader_buffer_load : enable
#extension GL_EXT_shader_image_load_store : enable

#define GL_FRAGMENT_PRECISION_HIGH 1
#define multisample 0 

#define atomic		1
#define inverse		1
#define COUNTERS	30
#define COUNTERS2	COUNTERS/2

// for resolution : 1024 x 768
#define COUNTERS_X		256
#define COUNTERS_Y		96	
#define COUNTERS_W		4	

int hashFunction(ivec2 coords)
{
	ivec2 tile = ivec2(coords.x / COUNTERS_X, coords.y / COUNTERS_Y);
	return tile.x * COUNTERS_W + tile.y;

	// EG 2012 paper's hash function: [hash_id = (coords.x + 1024*coords.y) % COUNTERS]
}

#define sigma		20.0f