#define K_SIZE				8
#define BUCKET_SIZE_32d		((K_SIZE > 32) ? K_SIZE : 32) 
#define BUCKET_SIZE			BUCKET_SIZE_32d * 32
#define	BUCKET_SIZE_div		1.0f / float(BUCKET_SIZE)