﻿#version 430 core
#extension GL_NV_gpu_shader5 : enable

#define PAGE_SIZE			4
#define early_Z				1
#define multipass			0
#define packing				0

// SIZE
#define PAGE_SIZE			4
#define KB_SIZE				8
#define STENCIL_SIZE		32
#define BUCKET_SIZE			8

#define HEAP_SIZE			8
#define HEAP_SIZE_1p		HEAP_SIZE + 1
#define HEAP_SIZE_1n		HEAP_SIZE - 1
#define HEAP_SIZE_LOG2		log2(HEAP_SIZE)

// 1.0f -> 32uint
#define Packed_1f			4294967295U

// Applications
#define trimless			0
#define trimming			0
#define collision			0