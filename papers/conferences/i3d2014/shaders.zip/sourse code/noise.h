﻿float random(int n) // [-1,...,1]
{
	n = (n << 13) ^ n;
	return 1.0 - float( (n * (n * n * 15731 + 789221) + 1376312589) & 0x7fffffff) / 1073741824.0;
}

void clipping(vec2 FragCoord, int InstanceID)
{
	if(random(int(FragCoord.x) + width*(int(FragCoord.y) + InstanceID))
		discard;
	return;
}