﻿#extension GL_NV_gpu_shader5 : enable

#define atomic			1
#define inverse			1
#define COUNTERS		32
#define COUNTERS_2d		COUNTERS >> 1

// for resolution : 1024 x 768
#define COUNTERS_X		256				// {S-Buffer}
#define COUNTERS_Y		96				// {S-Buffer}
#define COUNTERS_W		4				// {S-Buffer}

int hashFunction(ivec2 coords)
{
	ivec2 tile = ivec2(coords.x / COUNTERS_X, coords.y / COUNTERS_Y);
	return tile.x * COUNTERS_W + tile.y;
}