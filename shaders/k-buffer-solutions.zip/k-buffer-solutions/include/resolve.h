﻿	
//------
#define sigma	  20.0f
//------

	uniform int   layer;
	uniform bool  closest;
	uniform bool  correctAlpha;
	uniform bool  useTransparency;
	uniform bool  useTranslucency;
	uniform vec4  color_background;
	uniform float transparency;

	vec4 resolveLayer(const int num)
	{
		sort(num);
		return unpackUnorm4x8(uint(fragments[layer].x)).abgr;
	}

	vec4 resolveAlphaBlend(const int num)
	{
		sort(num);

		vec2  Ci;
		vec4  C0=vec4(0.0f), color, finalColor=vec4(0.0f);
		float thickness=0.0f, prevZ = 0.0f, thicknessAlpha=0.0f, Zi1;
	
		for(int i=0; i<num; i++)
		{
			Ci = fragments[i];
			if(i==0)
			{
				C0 = unpackUnorm4x8(uint(Ci.r)).abgr;
				if(correctAlpha) thicknessAlpha = Ci.g*0.5f;
			}

			if(useTranslucency)
			{
				if(i%2==1) thickness += Ci.g - prevZ;
				prevZ = Ci.g;
			}
			else if(useTransparency)
			{
				color = vec4(unpackUnorm4x8(uint(Ci.r)).abg, transparency);
				if(correctAlpha)
				{
					if(i%2 == num%2)
					{
						Zi1 = fragments[i+1].g;
						Zi1 = abs(Zi1);
						thicknessAlpha = (Zi1-Ci.g)*0.5f;
					}
					color.w		= 1.0f - pow(1.0f - color.w, thicknessAlpha*sigma);
					color.rgb  *= color.a;
				}
				finalColor += color*(1.0f-finalColor.a);
			}
		}

		if(useTransparency)
			finalColor += color_background*(1.0f-finalColor.a);
		else  
		{
			const float Ka    = 0.8f;
			const vec4  jade  = vec4(0.4, 0.14, 0.11, 1.0)*8.0f;
			const vec4  green = vec4(0.3, 0.7 , 0.1 , 1.0)*4.0f;
		
			finalColor = (Ka*exp(-sigma*thickness)*vec4(1.0f) + C0)*jade;	
		}

		return finalColor;
	}

	vec4 resolveClosest(const int num)
	{
		vec2 Ci, maxC = vec2(0.0f,1.0f);

		for(int i=0; i<num; i++)
		{
			Ci = fragments[i];
			if(Ci.g < maxC.g)
				maxC = Ci;
		}
		return unpackUnorm4x8(uint(maxC.r)).abgr;
	}

	vec4 resolve(const int num)
{
	vec4 c;
	if(useTransparency || useTranslucency)
		c = resolveAlphaBlend(num);
	else
	{
		if(closest)
			return resolveClosest (num);
		if(layer+1 > num)
			discard;

		c = resolveLayer(num);
	}
	return c;
}