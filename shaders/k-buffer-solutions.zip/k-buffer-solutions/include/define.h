#define INTEL_ordering		0		// enable for INTEL  hardware semaphore
#define NV_interlock		0		// enable for Nvidia hardware semaphore

#if INTEL_ordering
#version 430 core
#else
#version 450 core
#extension GL_NV_gpu_shader5 : enable
#endif

#define packing				0		// K-buffer packing option
#define multipass			0		// K-buffer multiple passes option

#define AB_SIZE				100		// A-buffer size

#define KB_SIZE			    8		// K-buffer size
#define KB_SIZE_1p		    KB_SIZE + 1
#define KB_SIZE_1n		    KB_SIZE - 1
#define KB_SIZE_2d		    KB_SIZE >> 1
#define KB_SIZE_LOG2		log2(KB_SIZE)

#define MRT_SIZE			8		// Max Multiple Render Targets - MRT
#define MRT_SIZE_2			MRT_SIZE*2

#define STENCIL_SIZE		((KB_SIZE < 32) ? KB_SIZE : 32)

#define MAX_ITERATIONS		200		// software semaphore iterations
#define ARRAY_VS_HEAP		16		// KB+ method switch

#define HISTOGRAM_SIZE		1024	// Histogram size

#define LOCAL_SIZE			32		// Local sorting array length
#define LOCAL_SIZE_1n		LOCAL_SIZE - 1
#define INSERTION_VS_SHELL	16		// Fragment Length Sorting Method Switch

#define Packed_1f			4294967295U // 0xFFFFFFFFU