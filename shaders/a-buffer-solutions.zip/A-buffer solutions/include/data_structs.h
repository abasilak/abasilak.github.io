	struct NodeTypeArray
	{
		float depth;
		uint  color;
	};
	
	struct NodeTypeLL
	{
		float depth;
		uint  color;

		uint  next;
	};

	struct NodeTypeDataLL_Double
	{
		float	depth;

		uint	albedo;
		uint	normal;
		uint	specular;
		uint	ior_opacity;

		uint	next;
		uint	prev;
	};

	// Decoupled Versions
	// NodeTypeData (Attributes)
	struct NodeTypeData
	{
		uint	albedo;
		uint	normal;
		uint	specular;
		uint	ior_opacity;
	};

	struct NodeTypeLL_Double
	{
		float	depth;

		uint next;
		uint prev;
	};