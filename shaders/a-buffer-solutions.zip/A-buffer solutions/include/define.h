#version 450 core
#extension GL_NV_gpu_shader5 : enable

#define B_SIZE				10		// Buckets  size
#define B_SIZE_1n			B_SIZE - 1
#define AB_SIZE				100		// A-buffer size

#define LOCAL_SORT			0		// Toggle between local and global sorting
#define LOCAL_SIZE			32		// Local  sorting array length
#define LOCAL_SIZE_1n		LOCAL_SIZE - 1
#define GLOBAL_SIZE			AB_SIZE	// Global sorting array length
#define GLOBAL_SIZE_2d		GLOBAL_SIZE >> 1 // divided by 2
#define INSERTION_VS_SHELL	16		// Fragment Length Sorting Method Switch

#define Packed_1f			4294967295U